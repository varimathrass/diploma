﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System;
using System.Security.Permissions;

[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, Execution = true)]

[assembly: AssemblyTitle("Aga.Controls")]
[assembly: AssemblyCopyright("Copyright © Andrey Gliznetsov 2006 - 2009")]
[assembly: AssemblyDescription("http://sourceforge.net/projects/treeviewadv/")]

[assembly: AssemblyVersion("1.7.0.0")]
